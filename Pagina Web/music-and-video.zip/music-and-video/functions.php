<?php if( ! defined( 'ABSPATH' ) ) exit;

/**
 * functions and definitions
 */

require get_template_directory() . '/include/template-functions.php';
